pref("fullfullscreen.start", true);
pref("fullfullscreen.noautohide", true);
pref("fullfullscreen.notabs", true);
pref("fullfullscreen.noscroll", true);
